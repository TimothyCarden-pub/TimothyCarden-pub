_G.Settings = {
  buttonRelativeX = 0.5,  -- 50% from left
  buttonRelativeY = 0.5,  -- 50% from top
  showButton = 1,         -- Show button initially
  toggleMinOpacity = 0.5, -- Minimum opacity
  toggleMaxOpacity = 1.0,  -- Maximum opacity
  mainMinOpacity = 0.7,    -- Opacity for main window
}
